#Requires -Module FailoverClusterDsc

<#
    .DESCRIPTION
        This example shows how to set the quorum in a failover cluster to use
        node and cloud majority.
#>

Configuration ClusterQuorum_SetQuorumToNodeAndCloudMajorityConfig
{
    param
    (
    [Parameter(Mandatory)]
    [String]$installStorageAccountName,

    [Parameter(Mandatory)]
    [String]$StorageAccountAccessKey

    )
    Import-DscResource -ModuleName FailoverClusterDsc

    Node localhost
    {
        ClusterQuorum 'SetQuorumToNodeAndCloudMajority'
        {
            IsSingleInstance        = 'Yes'
            Type                    = 'NodeAndCloudMajority'
            Resource                =  $installStorageAccountName
            StorageAccountAccessKey =  $StorageAccountAccessKey
        }
    }
}