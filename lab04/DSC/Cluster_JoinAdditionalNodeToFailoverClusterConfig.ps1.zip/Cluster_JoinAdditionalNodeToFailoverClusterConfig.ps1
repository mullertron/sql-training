

#Requires -Module FailoverClusterDsc

<#
    .DESCRIPTION
        This example shows how to add an additional node to the failover cluster.
#>

Configuration Cluster_JoinAdditionalNodeToFailoverClusterConfig
{
    param
    (
        [Parameter(Mandatory)]
        [String]$clustername,

        [Parameter(Mandatory)]
        [String]$staticIPAddress,


        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )

    Import-DscResource -ModuleName FailoverClusterDsc
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WindowsFeature AddFailoverFeature
        {
            Ensure = 'Present'
            Name   = 'Failover-clustering'
        }

        WindowsFeature AddRemoteServerAdministrationToolsClusteringPowerShellFeature
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-PowerShell'
            DependsOn = '[WindowsFeature]AddFailoverFeature'
        }

        WindowsFeature AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-CmdInterface'
            DependsOn = '[WindowsFeature]AddRemoteServerAdministrationToolsClusteringPowerShellFeature'
        }

        WaitForCluster WaitForCluster
        {
            Name             = $clustername
            RetryIntervalSec = 10
            RetryCount       = 60
            DependsOn        = '[WindowsFeature]AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature'
        }

        Cluster JoinSecondNodeToCluster
        {
            Name                          = $clustername
            StaticIPAddress               = $staticIPAddress
            DomainAdministratorCredential = $DomainCreds
            DependsOn                     = '[WaitForCluster]WaitForCluster'
        }
    }
}